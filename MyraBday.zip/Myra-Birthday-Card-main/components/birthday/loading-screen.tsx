"use client"

import { useEffect, useState } from "react"

interface LoadingScreenProps {
  onComplete: () => void
}

export function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [fadeOut, setFadeOut] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => setFadeOut(true), 400)
          setTimeout(() => onComplete(), 1200)
          return 100
        }
        return prev + 2
      })
    }, 60)
    return () => clearInterval(interval)
  }, [onComplete])

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-background px-6 transition-opacity duration-700 ${
        fadeOut ? "opacity-0" : "opacity-100"
      }`}
    >
      <div className="mb-8 animate-bounce-gentle">
        <svg width="80" height="90" viewBox="0 0 80 90" fill="none" aria-hidden="true" className="sm:w-24 sm:h-[108px]">
          <rect x="37" y="8" width="6" height="18" rx="3" fill="#fbbf24" />
          <ellipse cx="40" cy="6" rx="5" ry="7" fill="#fb923c" className="animate-flicker" />
          <ellipse cx="40" cy="5" rx="3" ry="4" fill="#fde68a" className="animate-flicker" />
          <rect x="15" y="26" width="50" height="20" rx="4" fill="#f9a8d4" />
          <path d="M15 30 Q20 22, 25 30 Q30 22, 35 30 Q40 22, 45 30 Q50 22, 55 30 Q60 22, 65 30" stroke="#ffffff" strokeWidth="3" fill="none" />
          <rect x="10" y="46" width="60" height="24" rx="4" fill="#f472b6" />
          <circle cx="25" cy="58" r="3" fill="#fde68a" />
          <circle cx="40" cy="58" r="3" fill="#93c5fd" />
          <circle cx="55" cy="58" r="3" fill="#fde68a" />
          <ellipse cx="40" cy="72" rx="35" ry="6" fill="#fce7f3" />
        </svg>
      </div>

      <p
        className="text-lg sm:text-xl font-semibold text-foreground mb-6 text-center"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {"Loading Myra's birthday surprise..."}
      </p>

      <div className="w-56 sm:w-72 h-3 bg-secondary rounded-full overflow-hidden">
        <div
          className="h-full bg-primary rounded-full transition-all duration-150 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      <p className="text-sm sm:text-base text-muted-foreground mt-4 font-semibold">{progress}%</p>
    </div>
  )
}
