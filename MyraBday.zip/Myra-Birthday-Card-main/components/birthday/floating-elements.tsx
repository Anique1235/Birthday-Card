"use client"

import { useEffect, useState } from "react"

interface FloatingBalloon {
  id: number
  left: number
  delay: number
  duration: number
  color: string
  size: number
}

interface Sparkle {
  id: number
  left: number
  top: number
  delay: number
  size: number
}

const BALLOON_COLORS = ["#f9a8d4", "#93c5fd", "#c4b5fd", "#fde68a", "#a7f3d0"]

export function FloatingBalloons() {
  const [balloons, setBalloons] = useState<FloatingBalloon[]>([])

  useEffect(() => {
    const count = window.innerWidth < 500 ? 8 : 12
    const generated: FloatingBalloon[] = Array.from({ length: count }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 8,
      duration: 10 + Math.random() * 10,
      color: BALLOON_COLORS[i % BALLOON_COLORS.length],
      size: window.innerWidth < 500 ? 18 + Math.random() * 12 : 24 + Math.random() * 20,
    }))
    setBalloons(generated)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {balloons.map((b) => (
        <div
          key={b.id}
          className="absolute animate-float-up"
          style={{
            left: `${b.left}%`,
            bottom: "-60px",
            animationDelay: `${b.delay}s`,
            animationDuration: `${b.duration}s`,
          }}
        >
          <svg width={b.size} height={b.size * 1.3} viewBox="0 0 40 52" fill="none">
            <ellipse cx="20" cy="18" rx="16" ry="18" fill={b.color} opacity="0.5" />
            <ellipse cx="20" cy="18" rx="10" ry="12" fill="white" opacity="0.12" />
            <path d="M20 36 L20 52" stroke={b.color} strokeWidth="1" opacity="0.3" />
          </svg>
        </div>
      ))}
    </div>
  )
}

export function SparkleOverlay() {
  const [sparkles, setSparkles] = useState<Sparkle[]>([])

  useEffect(() => {
    const count = window.innerWidth < 500 ? 12 : 20
    const generated: Sparkle[] = Array.from({ length: count }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 100,
      delay: Math.random() * 5,
      size: 3 + Math.random() * 6,
    }))
    setSparkles(generated)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {sparkles.map((s) => (
        <div
          key={s.id}
          className="absolute animate-twinkle"
          style={{ left: `${s.left}%`, top: `${s.top}%`, animationDelay: `${s.delay}s` }}
        >
          <svg width={s.size} height={s.size} viewBox="0 0 16 16" fill="none">
            <path d="M8 0 L9.5 6.5 L16 8 L9.5 9.5 L8 16 L6.5 9.5 L0 8 L6.5 6.5 Z" fill="#fbbf24" opacity="0.5" />
          </svg>
        </div>
      ))}
    </div>
  )
}

export function ConfettiOverlay() {
  const [confetti, setConfetti] = useState<Array<{
    id: number
    left: number
    delay: number
    duration: number
    color: string
    rotation: number
  }>>([])

  useEffect(() => {
    const colors = ["#f472b6", "#93c5fd", "#c084fc", "#fbbf24", "#34d399", "#fb923c"]
    const count = window.innerWidth < 500 ? 20 : 30
    const generated = Array.from({ length: count }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 4,
      duration: 3 + Math.random() * 4,
      color: colors[i % colors.length],
      rotation: Math.random() * 360,
    }))
    setConfetti(generated)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-10" aria-hidden="true">
      {confetti.map((c) => (
        <div
          key={c.id}
          className="absolute animate-confetti-fall"
          style={{
            left: `${c.left}%`,
            top: "-20px",
            animationDelay: `${c.delay}s`,
            animationDuration: `${c.duration}s`,
          }}
        >
          <div
            className="w-1.5 h-2.5 rounded-sm"
            style={{ backgroundColor: c.color, transform: `rotate(${c.rotation}deg)` }}
          />
        </div>
      ))}
    </div>
  )
}
