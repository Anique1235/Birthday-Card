"use client"

import { useState } from "react"

interface MessageRevealProps {
  onComplete: () => void
}

export function MessageReveal({ onComplete }: MessageRevealProps) {
  const [opened, setOpened] = useState(false)

  return (
    <section className="flex flex-col items-center justify-center min-h-[100dvh] px-5 py-8 text-center animate-fade-in-up">
      {!opened ? (
        <>
          <div className="mb-8 animate-bounce-gentle">
            <svg width="96" height="80" viewBox="0 0 120 100" aria-hidden="true" className="sm:w-[120px] sm:h-[100px]">
              <rect x="10" y="30" width="100" height="65" rx="6" fill="#fce7f3" stroke="#f9a8d4" strokeWidth="2" />
              <path d="M10 30 L60 65 L110 30" fill="#f9a8d4" stroke="#f472b6" strokeWidth="2" />
              <path d="M60 55 C60 50 53 45 53 50 C53 55 60 62 60 62 C60 62 67 55 67 50 C67 45 60 50 60 55Z" fill="#f472b6" />
            </svg>
          </div>
          <p
            className="text-lg sm:text-xl md:text-2xl text-muted-foreground mb-2 px-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Your brother sent you something
          </p>
          <p className="text-xs sm:text-sm text-muted-foreground/60 mb-8 px-6">
            from miles away, but straight from the heart
          </p>
          <button
            onClick={() => setOpened(true)}
            className="px-8 py-4 bg-primary text-primary-foreground font-bold text-base sm:text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 active:scale-95"
          >
            Open Message
          </button>
        </>
      ) : (
        <div className="animate-fade-in-up w-full">
          <div className="relative bg-card rounded-3xl p-6 sm:p-8 md:p-10 shadow-2xl border border-border max-w-[340px] sm:max-w-sm md:max-w-md mx-auto">
            {/* Sparkles */}
            {[...Array(6)].map((_, i) => {
              const positions = [
                { l: -2, t: -2 }, { l: 50, t: -4 }, { l: 100, t: 8 },
                { l: -2, t: 95 }, { l: 50, t: 102 }, { l: 102, t: 80 },
              ]
              return (
                <svg
                  key={i}
                  className="absolute animate-twinkle"
                  style={{ left: `${positions[i].l}%`, top: `${positions[i].t}%`, animationDelay: `${i * 0.3}s` }}
                  width="16" height="16" viewBox="0 0 16 16" fill="none"
                >
                  <path d="M8 0 L9.5 6.5 L16 8 L9.5 9.5 L8 16 L6.5 9.5 L0 8 L6.5 6.5 Z" fill="#fbbf24" opacity="0.7" />
                </svg>
              )
            })}

            {/* Floating hearts */}
            {[...Array(4)].map((_, i) => (
              <div
                key={`heart-${i}`}
                className="absolute animate-float-heart text-primary"
                style={{ left: `${15 + i * 22}%`, bottom: "100%", animationDelay: `${i * 0.7}s`, fontSize: `${14 + i * 3}px` }}
              >
                {"\u2665"}
              </div>
            ))}

            <h2
              className="text-2xl sm:text-3xl md:text-4xl text-primary mb-3"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Happy Birthday
            </h2>
            <p
              className="text-base sm:text-xl md:text-2xl text-foreground leading-relaxed"
              style={{ fontFamily: "var(--font-display)" }}
            >
              to my one and only online sister
            </p>
            <p
              className="text-xl sm:text-3xl md:text-4xl text-primary mt-2"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Myra
            </p>
            <p className="text-xs sm:text-sm text-muted-foreground mt-4">
              distance means nothing when someone means everything
            </p>
          </div>

          <button
            onClick={onComplete}
            className="mt-7 px-7 py-3.5 bg-primary text-primary-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 text-base sm:text-lg"
          >
            Read the full letter
          </button>
        </div>
      )}
    </section>
  )
}
