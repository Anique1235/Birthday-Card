"use client"

import { useEffect, useState } from "react"

export function FinalMessage() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 200)
    return () => clearTimeout(timer)
  }, [])

  const paragraphs = [
    "Hieee Myraaa \u{1F97A}\u{1F496}\u{2728}",
    "Happy Birthday \u{1F90D}\u{2728}",
    "Today isn\u2019t just about celebrating a date\u2026 it\u2019s about celebrating the beautiful soul you are and the warmth you bring into this world.",
    "People often say the strongest relationships are the ones connected by blood. But sometimes life teaches us something even more meaningful \u2014 that some bonds are chosen by the heart, not written by blood.",
    "We may not share the same family.\nWe may not have grown up together.\nWe may not be connected by blood\u2026\n\nAnd yes, we met through a screen.",
    "But what we share has never felt \u201Cjust online\u201D to me.",
    "The care you give, the warmth in your words, the way you listen without judging, the way you stand by me \u2014 all of that feels real. Genuine. Pure. \u{1F90D}",
    "You didn\u2019t become my sister because we were born into the same house.\nYou became my sister because you chose to care.\nBecause you chose to stay.\nBecause you chose to treat me like family.",
    "And that choice means everything.",
    "There are moments when things feel heavy, and somehow just talking to you makes them lighter. That\u2019s not something everyone can do. That\u2019s your heart.",
    "Distance might say we\u2019re far.\nBlood might say we\u2019re not related.\nBut my heart knows \u2014 you are my sister in the truest way that matters.",
    "Not everyone is blessed to find someone who feels like family without sharing blood. I truly feel grateful that life connected us.",
    "On your special day, I pray your life becomes as warm and comforting as the love you give to others.\nMay happiness walk beside you.\nMay success find you easily.\nMay peace stay within you.\nAnd may you always feel valued, respected, and deeply appreciated.",
    "You deserve a world that is gentle with you.\nYou deserve smiles that never fade.\nYou deserve love that never leaves.",
    "Happy Birthday once again, my sister \u{1F90D}\u{2728}",
    "And always remember this \u2014\nwe may not be connected by blood, and we may have met online\u2026 but the bond we share is real to me.",
    "Your brother,\nyour Anique, is always here for you. No matter what. \u{1F90D}\u{2728}",
  ]

  return (
    <section className="flex flex-col items-center min-h-[100dvh] px-5 py-10 sm:py-14 text-center relative overflow-hidden">
      {/* Floating hearts background */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        {[...Array(10)].map((_, i) => {
          const positions = [
            { l: 5, t: 8 }, { l: 18, t: 32 }, { l: 30, t: 62 }, { l: 45, t: 14 },
            { l: 58, t: 48 }, { l: 70, t: 78 }, { l: 82, t: 22 }, { l: 92, t: 55 },
            { l: 12, t: 82 }, { l: 75, t: 90 },
          ]
          return (
            <div
              key={i}
              className="absolute animate-float-heart-slow text-primary/15"
              style={{ left: `${positions[i].l}%`, top: `${positions[i].t}%`, animationDelay: `${i * 0.5}s`, fontSize: `${14 + (i % 4) * 4}px` }}
            >
              {"\u2665"}
            </div>
          )
        })}
      </div>

      <div
        className={`relative z-10 w-full max-w-[360px] sm:max-w-md md:max-w-2xl mx-auto transition-all duration-1000 ${
          visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <h2
          className="text-2xl sm:text-3xl md:text-4xl text-primary mb-6 sm:mb-8"
          style={{ fontFamily: "var(--font-display)" }}
        >
          For you, Myra...
        </h2>

        <div className="bg-card/80 backdrop-blur-sm rounded-3xl p-5 sm:p-7 md:p-10 shadow-2xl border border-border text-left">
          {paragraphs.map((paragraph, index) => (
            <p
              key={index}
              className="text-sm sm:text-base md:text-lg text-foreground leading-relaxed mb-4 sm:mb-5 last:mb-0 animate-fade-in-up whitespace-pre-line"
              style={{ animationDelay: `${0.5 + index * 0.25}s`, animationFillMode: "both" }}
            >
              {paragraph}
            </p>
          ))}
        </div>

        <div
          className="mt-6 sm:mt-10 animate-fade-in-up"
          style={{ animationDelay: "5.5s", animationFillMode: "both" }}
        >
          <div className="flex justify-center gap-2.5 mt-5">
            {[...Array(5)].map((_, i) => (
              <svg
                key={i}
                className="animate-twinkle"
                style={{ animationDelay: `${i * 0.3}s` }}
                width="16" height="16" viewBox="0 0 16 16" fill="none"
              >
                <path d="M8 0 L9.5 6.5 L16 8 L9.5 9.5 L8 16 L6.5 9.5 L0 8 L6.5 6.5 Z" fill="#fbbf24" opacity="0.7" />
              </svg>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
