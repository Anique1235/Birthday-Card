"use client"

import { useState } from "react"

interface BirthdayQuizProps {
  onComplete: () => void
}

const QUESTIONS = [
  {
    question: "What is the first thing your brother does when he comes online?",
    options: ["Texts you immediately", "Lurks silently then suddenly appears", "Sends a meme without any context", "Complains about something random"],
    correctIndex: 0,
    reaction: "Obviously! Checking on you is literally my first priority. Always.",
  },
  {
    question: "When you suddenly go offline without saying bye, what does your brother do?",
    options: ["Panics and sends 47 messages", "Waits patiently (yeah right)", "Stalks your last seen like a detective", "All of the above in exactly that order"],
    correctIndex: 3,
    reaction: "Don't just disappear like that! My heart can't take it, sis!",
  },
  {
    question: "What would your brother do if someone made you cry online?",
    options: ["Type an angry paragraph he'll never send", "Ask for their username immediately", "Comfort you first, plan revenge later", "All of the above simultaneously"],
    correctIndex: 2,
    reaction: "You come first, always. But I'm still noting down that username...",
  },
  {
    question: "What does your brother say when you're sad and he can't be there in person?",
    options: ["\"I wish I could hug you right now\"", "\"Should I send you food online somehow?\"", "\"I'm right here, talk to me\"", "All of these, depending on the day"],
    correctIndex: 3,
    reaction: "The hardest part of being far away is not being able to just show up when you need me.",
  },
  {
    question: "What is the one thing your brother would do if he could meet you in real life?",
    options: ["Give you the tightest hug ever", "Annoy you 10x more in person", "Bring you every snack that exists", "Probably cry but pretend it's allergies"],
    correctIndex: 0,
    reaction: "One day I'll give you that hug for real, Myra. And I'm never letting go.",
  },
  {
    question: "What would your brother never say directly but means every single day?",
    options: ["\"You changed my life\"", "\"I'm grateful the internet brought us together\"", "\"You're the sister I chose and I'd choose you every time\"", "All of the above and so much more"],
    correctIndex: 3,
    reaction: "I mean every single word. The internet gave me the best sister in the world.",
  },
]

export function BirthdayQuiz({ onComplete }: BirthdayQuizProps) {
  const [currentQ, setCurrentQ] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [showReaction, setShowReaction] = useState(false)
  const [score, setScore] = useState(0)
  const [finished, setFinished] = useState(false)

  const question = QUESTIONS[currentQ]

  const handleSelect = (index: number) => {
    if (showReaction) return
    setSelectedOption(index)
    setShowReaction(true)
    if (index === question.correctIndex) setScore((s) => s + 1)
  }

  const handleNext = () => {
    if (currentQ < QUESTIONS.length - 1) {
      setCurrentQ((q) => q + 1)
      setSelectedOption(null)
      setShowReaction(false)
    } else {
      setFinished(true)
    }
  }

  const getScoreMessage = () => {
    if (score === QUESTIONS.length) return "You know your online brother PERFECTLY! We really are connected beyond the screen, Myra!"
    if (score >= 4) return "You know me so well even from miles away! That's the power of our bond, sis!"
    if (score >= 2) return "Not bad! But clearly we need more late-night chat sessions to fix this!"
    return "Myra... do you even read my messages?! Just kidding, love you regardless!"
  }

  if (finished) {
    return (
      <section className="flex flex-col items-center justify-center min-h-[100dvh] px-5 py-8 text-center animate-fade-in-up">
        <div className="bg-card rounded-3xl p-6 sm:p-8 shadow-2xl border border-border w-full max-w-[340px] sm:max-w-sm">
          <h2
            className="text-2xl sm:text-3xl text-primary mb-3"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Quiz Complete!
          </h2>
          <p className="text-4xl sm:text-5xl font-bold text-foreground mb-3">
            {score}/{QUESTIONS.length}
          </p>
          <p className="text-sm sm:text-base text-muted-foreground mb-5 leading-relaxed">
            {getScoreMessage()}
          </p>
          <div className="flex justify-center gap-1.5 mb-6">
            {[...Array(QUESTIONS.length)].map((_, i) => (
              <svg key={i} width="24" height="24" viewBox="0 0 24 24" fill={i < score ? "#fbbf24" : "#e5e7eb"} className="sm:w-7 sm:h-7">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
            ))}
          </div>
          <button
            onClick={onComplete}
            className="w-full px-6 py-3.5 bg-primary text-primary-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 text-base sm:text-lg"
          >
            Next
          </button>
        </div>
      </section>
    )
  }

  return (
    <section className="flex flex-col items-center justify-center min-h-[100dvh] px-5 py-8 text-center animate-fade-in-up">
      {/* Progress dots */}
      <div className="flex gap-2 mb-5">
        {QUESTIONS.map((_, i) => (
          <div
            key={i}
            className={`h-2 rounded-full transition-all duration-300 ${
              i <= currentQ ? "bg-primary w-6 sm:w-8" : "bg-border w-4 sm:w-5"
            }`}
          />
        ))}
      </div>

      <h2
        className="text-base sm:text-xl md:text-2xl text-primary mb-4 px-2"
        style={{ fontFamily: "var(--font-display)" }}
      >
        How well do you know your brother, Myra?
      </h2>

      <div className="bg-card rounded-3xl p-5 sm:p-7 shadow-2xl border border-border w-full max-w-[340px] sm:max-w-md">
        <p className="text-xs sm:text-sm text-muted-foreground mb-2.5 font-semibold">
          Question {currentQ + 1} of {QUESTIONS.length}
        </p>

        <h3 className="text-sm sm:text-base md:text-lg font-bold text-foreground mb-5 leading-relaxed">
          {question.question}
        </h3>

        <div className="flex flex-col gap-2.5 mb-4">
          {question.options.map((option, i) => {
            let optionStyle = "bg-secondary text-secondary-foreground hover:bg-primary/10"
            if (showReaction) {
              if (i === question.correctIndex) optionStyle = "bg-[#34d399] text-[#064e3b] scale-[1.02]"
              else if (i === selectedOption && i !== question.correctIndex) optionStyle = "bg-destructive/20 text-destructive"
              else optionStyle = "bg-secondary/50 text-muted-foreground"
            }

            return (
              <button
                key={i}
                onClick={() => handleSelect(i)}
                disabled={showReaction}
                className={`w-full px-4 py-3 rounded-xl font-semibold text-left transition-all duration-300 text-sm sm:text-base leading-snug ${optionStyle} ${
                  !showReaction ? "active:scale-95" : ""
                }`}
              >
                {option}
              </button>
            )
          })}
        </div>

        {showReaction && (
          <div className="animate-fade-in-up">
            <div className="bg-secondary rounded-xl p-3.5 mb-4">
              <p className="text-xs sm:text-sm md:text-base text-foreground font-semibold leading-relaxed">
                {selectedOption === question.correctIndex ? "Correct! " : "Wrong answer, but... "}
                {question.reaction}
              </p>
            </div>
            <button
              onClick={handleNext}
              className="w-full px-6 py-3 bg-primary text-primary-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 text-sm sm:text-base"
            >
              {currentQ < QUESTIONS.length - 1 ? "Next Question" : "See Results"}
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
