"use client"

import Image from "next/image"

interface MainCardProps {
  onStart: () => void
}

export function MainCard({ onStart }: MainCardProps) {
  return (
    <section className="flex flex-col items-center justify-center min-h-[100dvh] px-5 py-10 text-center animate-fade-in-up">
      {/* Circular photo */}
      <div className="relative mb-7">
        <div className="absolute -inset-4 bg-primary/10 rounded-full blur-2xl animate-pulse-slow" />
        <div className="relative z-10 w-40 h-40 sm:w-52 sm:h-52 md:w-60 md:h-60 rounded-full overflow-hidden border-4 border-primary/30 shadow-xl animate-bounce-gentle">
          <div className="absolute inset-0 rounded-full border-4 border-primary/10 z-20 pointer-events-none" />
          <Image
            src="/images/birthday-girl.png"
            alt="Myra - Birthday girl"
            fill
            className="object-cover object-top"
            priority
          />
        </div>
        <div className="absolute -inset-3 rounded-full border-2 border-dashed border-primary/20 animate-[spin_20s_linear_infinite] z-0" />
      </div>

      <p className="text-sm sm:text-base text-muted-foreground mb-1.5 font-semibold tracking-widest uppercase">
        25th February
      </p>

      <h1
        className="text-3xl sm:text-4xl md:text-5xl text-foreground mb-1.5 leading-tight text-balance"
        style={{ fontFamily: "var(--font-display)" }}
      >
        A cutiepie was born today
      </h1>
      <p
        className="text-xl sm:text-2xl md:text-3xl text-primary font-bold mb-3"
        style={{ fontFamily: "var(--font-display)" }}
      >
        21 years ago
      </p>
      <p className="text-base sm:text-lg text-muted-foreground mb-8 font-semibold">
        {"My dear sister, Myra"}
      </p>

      <button
        onClick={onStart}
        className="group relative px-8 py-4 bg-primary text-primary-foreground font-bold text-base sm:text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 active:scale-95"
      >
        <span className="relative z-10">Start the Surprise</span>
        <div className="absolute inset-0 bg-primary rounded-full animate-ping-slow opacity-30" />
      </button>
    </section>
  )
}
