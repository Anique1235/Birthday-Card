"use client"

import { useState } from "react"

interface CakeInteractionProps {
  onComplete: () => void
}

export function CakeInteraction({ onComplete }: CakeInteractionProps) {
  const [decorated, setDecorated] = useState(false)
  const [candlesSet, setCandlesSet] = useState(false)
  const [candlesBurning, setCandlesBurning] = useState(false)

  return (
    <section className="flex flex-col items-center justify-center min-h-[100dvh] px-5 py-8 text-center animate-fade-in-up relative overflow-hidden">
      <h2
        className="text-2xl sm:text-3xl md:text-4xl text-foreground mb-5 sm:mb-6"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {"Let's bake Myra's cake!"}
      </h2>

      {/* Full-screen decoration overlay */}
      {decorated && (
        <div className="fixed inset-0 pointer-events-none z-10 animate-fade-in" aria-hidden="true">
          {/* Balloons spread across screen */}
          {[...Array(14)].map((_, i) => (
            <div
              key={`deco-balloon-${i}`}
              className="absolute animate-float-balloon"
              style={{
                left: `${2 + i * 7}%`,
                top: `${5 + (i % 5) * 20}%`,
                animationDelay: `${i * 0.3}s`,
                animationDuration: `${2.5 + (i % 3)}s`,
              }}
            >
              <svg width={28 + (i % 3) * 6} height={(28 + (i % 3) * 6) * 1.3} viewBox="0 0 40 52" fill="none">
                <ellipse cx="20" cy="18" rx="16" ry="18" fill={["#f9a8d4","#93c5fd","#fde68a","#c4b5fd","#a7f3d0"][i % 5]} opacity="0.65" />
                <ellipse cx="16" cy="14" rx="5" ry="6" fill="white" opacity="0.2" />
                <path d="M20 36 Q22 42 18 52" stroke={["#f9a8d4","#93c5fd","#fde68a","#c4b5fd","#a7f3d0"][i % 5]} strokeWidth="1" opacity="0.4" />
              </svg>
            </div>
          ))}
          {/* Ribbons from top */}
          {[...Array(8)].map((_, i) => (
            <div
              key={`ribbon-${i}`}
              className="absolute animate-fade-in"
              style={{ left: `${i * 12.5}%`, top: 0, animationDelay: `${i * 0.1}s` }}
            >
              <svg width="18" height="140" viewBox="0 0 20 140">
                <path
                  d={`M10 0 Q${5 + (i % 2) * 10} 35 10 70 Q${15 - (i % 2) * 10} 105 10 140`}
                  stroke={["#f472b6","#93c5fd","#fbbf24","#c084fc","#34d399","#fb923c","#f9a8d4","#60a5fa"][i]}
                  strokeWidth="3"
                  fill="none"
                  opacity="0.45"
                />
              </svg>
            </div>
          ))}
          {/* Sparkle stars */}
          {[...Array(16)].map((_, i) => {
            const positions = [
              { l: 5, t: 15 }, { l: 18, t: 42 }, { l: 30, t: 75 }, { l: 42, t: 20 },
              { l: 55, t: 55 }, { l: 68, t: 85 }, { l: 78, t: 18 }, { l: 90, t: 50 },
              { l: 12, t: 65 }, { l: 35, t: 92 }, { l: 50, t: 8 }, { l: 65, t: 38 },
              { l: 82, t: 70 }, { l: 95, t: 25 }, { l: 22, t: 88 }, { l: 72, t: 92 },
            ]
            const pos = positions[i]
            return (
              <svg
                key={`deco-sparkle-${i}`}
                className="absolute animate-twinkle"
                style={{ left: `${pos.l}%`, top: `${pos.t}%`, animationDelay: `${i * 0.25}s` }}
                width="16" height="16" viewBox="0 0 16 16" fill="none"
              >
                <path d="M8 0 L9.5 6.5 L16 8 L9.5 9.5 L8 16 L6.5 9.5 L0 8 L6.5 6.5 Z" fill={["#fbbf24","#f472b6","#93c5fd"][i % 3]} opacity="0.55" />
              </svg>
            )
          })}
          {/* Confetti */}
          {[...Array(20)].map((_, i) => (
            <div
              key={`confetti-${i}`}
              className="absolute w-2 h-2 rounded-full animate-confetti-fall"
              style={{
                left: `${(i * 5) % 100}%`,
                top: "-8px",
                backgroundColor: ["#f472b6","#93c5fd","#fbbf24","#c084fc","#34d399"][i % 5],
                animationDelay: `${i * 0.2}s`,
                animationDuration: `${3 + (i % 4)}s`,
              }}
            />
          ))}
        </div>
      )}

      {/* Cake SVG */}
      <div className="relative w-64 h-64 sm:w-72 sm:h-72 md:w-80 md:h-80 mb-6 z-20">
        <svg viewBox="0 0 300 300" className="w-full h-full" aria-label="Birthday cake">
          <ellipse cx="150" cy="260" rx="130" ry="20" fill="#fce7f3" />
          <rect x="50" y="190" width="200" height="70" rx="10" fill="#f472b6" />
          <rect x="50" y="190" width="200" height="15" rx="6" fill="#f9a8d4" />
          <circle cx="90" cy="230" r="5" fill="#fde68a" />
          <circle cx="130" cy="230" r="5" fill="#93c5fd" />
          <circle cx="170" cy="230" r="5" fill="#fde68a" />
          <circle cx="210" cy="230" r="5" fill="#93c5fd" />
          <rect x="80" y="130" width="140" height="60" rx="8" fill="#f9a8d4" />
          <rect x="80" y="130" width="140" height="12" rx="6" fill="#fce7f3" />
          <path d="M80 140 Q95 125, 110 140 Q125 125, 140 140 Q155 125, 170 140 Q185 125, 200 140 Q215 125, 220 140" stroke="#ffffff" strokeWidth="4" fill="none" />
          <polygon points="110,165 113,158 120,158 114,153 116,146 110,150 104,146 106,153 100,158 107,158" fill="#fde68a" opacity="0.8" />
          <polygon points="170,170 173,163 180,163 174,158 176,151 170,155 164,151 166,158 160,163 167,163" fill="#93c5fd" opacity="0.8" />

          {/* Frosting hearts when decorated */}
          {decorated && (
            <g className="animate-fade-in">
              <text x="130" y="218" textAnchor="middle" fill="#fde68a" fontSize="16" fontFamily="sans-serif">{"\u2665"}</text>
              <text x="150" y="215" textAnchor="middle" fill="#ffffff" fontSize="18" fontFamily="sans-serif">{"\u2665"}</text>
              <text x="170" y="218" textAnchor="middle" fill="#fde68a" fontSize="16" fontFamily="sans-serif">{"\u2665"}</text>
            </g>
          )}

          {/* Candles */}
          {candlesSet && (
            <g className="animate-fade-in">
              {[110, 130, 150, 170, 190].map((x, i) => (
                <g key={`candle-${i}`}>
                  <rect x={x - 3} y={95} width={6} height={35} rx={3} fill={["#fbbf24", "#f472b6", "#93c5fd", "#c084fc", "#34d399"][i]} />
                  {candlesBurning && (
                    <g className="animate-flicker" style={{ transformOrigin: `${x}px 88px` }}>
                      <ellipse cx={x} cy={88} rx={7} ry={12} fill="#fb923c" />
                      <ellipse cx={x} cy={86} rx={4} ry={7} fill="#fde68a" />
                      <ellipse cx={x} cy={80} rx={2} ry={4} fill="#fff7ed" opacity="0.8" />
                      <ellipse cx={x} cy={86} rx={14} ry={16} fill="#fde68a" opacity="0.12" />
                    </g>
                  )}
                </g>
              ))}
            </g>
          )}
        </svg>
      </div>

      {/* Step buttons */}
      <div className="flex flex-col items-center gap-3.5 z-20 w-full max-w-xs">
        {!decorated && (
          <button
            onClick={() => setDecorated(true)}
            className="w-full px-6 py-3.5 bg-accent text-accent-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 text-base sm:text-lg"
          >
            Decorate
          </button>
        )}
        {decorated && !candlesSet && (
          <button
            onClick={() => setCandlesSet(true)}
            className="w-full px-6 py-3.5 bg-[#fbbf24] text-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 animate-fade-in text-base sm:text-lg"
          >
            Set Candles
          </button>
        )}
        {candlesSet && !candlesBurning && (
          <button
            onClick={() => setCandlesBurning(true)}
            className="w-full px-6 py-3.5 bg-destructive text-destructive-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 animate-fade-in text-base sm:text-lg"
          >
            Light Candles
          </button>
        )}
        {candlesBurning && (
          <button
            onClick={onComplete}
            className="w-full px-6 py-3.5 bg-primary text-primary-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 animate-fade-in text-base sm:text-lg"
          >
            Next
          </button>
        )}
      </div>
    </section>
  )
}
