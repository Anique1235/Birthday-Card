"use client"

import { useState, useEffect, useCallback, useRef } from "react"

interface BalloonPopProps {
  onComplete: () => void
}

interface FloatingBalloon {
  id: number
  color: string
  x: number
  y: number
  vx: number
  vy: number
  popped: boolean
  size: number
  wobbleOffset: number
}

const BALLOON_COLORS = [
  "#f472b6", "#93c5fd", "#fde68a", "#c4b5fd", "#a7f3d0",
  "#fca5a5", "#7dd3fc", "#fcd34d", "#d8b4fe", "#6ee7b7",
  "#fb923c", "#67e8f9", "#fbbf24", "#a78bfa", "#34d399",
  "#f87171", "#38bdf8", "#facc15", "#c084fc", "#2dd4bf",
  "#f9a8d4",
]

function getInitialBalloons(): FloatingBalloon[] {
  const w = typeof window !== "undefined" ? window.innerWidth : 375
  const h = typeof window !== "undefined" ? window.innerHeight : 667

  const cols = w < 500 ? 4 : 5
  const rows = Math.ceil(21 / cols)
  const cellW = w / cols
  const topPad = 90
  const bottomPad = 50
  const cellH = (h - topPad - bottomPad) / rows
  const baseSize = w < 500 ? 48 : 56

  return Array.from({ length: 21 }, (_, i) => {
    const col = i % cols
    const row = Math.floor(i / cols)
    const jitterX = (Math.random() - 0.5) * cellW * 0.6
    const jitterY = (Math.random() - 0.5) * cellH * 0.5
    const size = baseSize + Math.random() * 10

    return {
      id: i + 1,
      color: BALLOON_COLORS[i],
      x: Math.max(4, Math.min(w - size - 4, cellW * col + cellW / 2 + jitterX - size / 2)),
      y: Math.max(topPad, Math.min(h - size * 1.3 - bottomPad, topPad + cellH * row + cellH / 2 + jitterY)),
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.35 - 0.1,
      popped: false,
      size,
      wobbleOffset: Math.random() * Math.PI * 2,
    }
  })
}

export function BalloonPop({ onComplete }: BalloonPopProps) {
  const animRef = useRef<number>(0)
  const balloonsRef = useRef<FloatingBalloon[]>([])
  const timeRef = useRef(0)
  const [balloons, setBalloons] = useState<FloatingBalloon[]>([])
  const [poppedCount, setPoppedCount] = useState(0)
  const [allDone, setAllDone] = useState(false)
  const [popParticles, setPopParticles] = useState<{ id: number; x: number; y: number; color: string }[]>([])

  useEffect(() => {
    const initial = getInitialBalloons()
    balloonsRef.current = initial
    setBalloons(initial)
  }, [])

  useEffect(() => {
    const animate = () => {
      const w = window.innerWidth
      const h = window.innerHeight
      timeRef.current += 0.008

      balloonsRef.current = balloonsRef.current.map((b) => {
        if (b.popped) return b

        const wobbleX = Math.sin(timeRef.current * 0.4 + b.wobbleOffset) * 0.08
        const wobbleY = Math.cos(timeRef.current * 0.3 + b.wobbleOffset * 1.5) * 0.06

        let nx = b.x + b.vx + wobbleX
        let ny = b.y + b.vy + wobbleY
        let nvx = b.vx
        let nvy = b.vy

        if (nx < 2) { nvx = Math.abs(nvx) * 0.6 + 0.05; nx = 2 }
        else if (nx > w - b.size - 2) { nvx = -Math.abs(nvx) * 0.6 - 0.05; nx = w - b.size - 2 }

        if (ny < 80) { nvy = Math.abs(nvy) * 0.6 + 0.04; ny = 80 }
        else if (ny > h - b.size * 1.3 - 20) { nvy = -Math.abs(nvy) * 0.6 - 0.04; ny = h - b.size * 1.3 - 20 }

        nvx += (Math.random() - 0.5) * 0.02
        nvy += (Math.random() - 0.5) * 0.015 - 0.005

        const maxV = 0.6
        nvx = Math.max(-maxV, Math.min(maxV, nvx))
        nvy = Math.max(-maxV, Math.min(maxV, nvy))

        return { ...b, x: nx, y: ny, vx: nvx, vy: nvy }
      })

      setBalloons([...balloonsRef.current])
      animRef.current = requestAnimationFrame(animate)
    }

    animRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const popBalloon = useCallback((id: number) => {
    const b = balloonsRef.current.find((bl) => bl.id === id)
    if (!b || b.popped) return

    setPopParticles((prev) => [...prev, { id, x: b.x + b.size / 2, y: b.y + b.size / 2, color: b.color }])
    setTimeout(() => setPopParticles((prev) => prev.filter((p) => p.id !== id)), 700)

    balloonsRef.current = balloonsRef.current.map((bl) => bl.id === id ? { ...bl, popped: true } : bl)
    setPoppedCount((c) => {
      const next = c + 1
      if (next === 21) setTimeout(() => setAllDone(true), 900)
      return next
    })
  }, [])

  return (
    <section
      className="relative w-full h-[100dvh] overflow-hidden select-none"
      style={{ touchAction: "manipulation" }}
    >
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 z-30 flex flex-col items-center pt-4 pb-3 bg-background/70 backdrop-blur-sm pointer-events-none">
        <h2
          className="text-xl sm:text-2xl md:text-3xl text-foreground mb-1"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Catch & Pop!
        </h2>
        <p className="text-xs sm:text-sm text-muted-foreground font-semibold mb-1.5">
          Tap the flying balloons, Myra!
        </p>
        <div className="flex items-center gap-2.5">
          <p className="text-sm sm:text-base font-bold text-primary">{poppedCount}/21</p>
          <div className="w-28 sm:w-40 h-2 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-300 ease-out"
              style={{ width: `${(poppedCount / 21) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Free-floating balloons */}
      {balloons.map((b) =>
        b.popped ? null : (
          <button
            key={b.id}
            onClick={() => popBalloon(b.id)}
            onTouchEnd={(e) => { e.preventDefault(); popBalloon(b.id) }}
            className="absolute z-10 cursor-pointer focus:outline-none active:scale-75 transition-transform duration-75"
            style={{ left: b.x, top: b.y, width: b.size, height: b.size * 1.3 }}
            aria-label={`Pop balloon number ${b.id}`}
          >
            <svg width={b.size} height={b.size * 1.3} viewBox="0 0 60 78" className="drop-shadow-md">
              <defs>
                <radialGradient id={`bg-${b.id}`} cx="35%" cy="28%">
                  <stop offset="0%" stopColor="white" stopOpacity="0.55" />
                  <stop offset="100%" stopColor={b.color} stopOpacity="1" />
                </radialGradient>
              </defs>
              <ellipse cx="30" cy="28" rx="27" ry="28" fill={`url(#bg-${b.id})`} />
              <ellipse cx="20" cy="18" rx="8" ry="10" fill="white" opacity="0.22" />
              <polygon points="27,56 33,56 35,61 25,61" fill={b.color} opacity="0.75" />
              <path d="M30 61 Q33 69 28 78" stroke={b.color} strokeWidth="1" fill="none" opacity="0.3" />
              <text
                x="30" y="34" textAnchor="middle" fill="white"
                fontSize={b.id >= 10 ? "14" : "16"} fontWeight="bold" fontFamily="sans-serif"
                style={{ textShadow: "0 1px 2px rgba(0,0,0,0.15)" }}
              >
                {b.id}
              </text>
            </svg>
          </button>
        )
      )}

      {/* Pop particles */}
      {popParticles.map((p) => (
        <div key={`pop-${p.id}`} className="absolute z-20 pointer-events-none" style={{ left: p.x, top: p.y }}>
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full animate-pop-particle"
              style={{
                width: 4 + (i % 3) * 2,
                height: 4 + (i % 3) * 2,
                backgroundColor: i % 2 === 0 ? p.color : "#fde68a",
                animationDelay: `${i * 0.02}s`,
                transform: `rotate(${i * 45}deg) translateY(-${16 + i * 2}px)`,
              }}
            />
          ))}
        </div>
      ))}

      {/* All popped overlay */}
      {allDone && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm animate-fade-in px-5">
          <div className="bg-card rounded-3xl p-6 sm:p-8 shadow-2xl border border-border max-w-[320px] sm:max-w-sm text-center">
            <div className="text-4xl sm:text-5xl mb-4">{"\u{1F389}"}</div>
            <p
              className="text-xl sm:text-2xl font-bold text-primary mb-2"
              style={{ fontFamily: "var(--font-display)" }}
            >
              All 21 popped!
            </p>
            <p className="text-sm sm:text-base text-foreground leading-relaxed">
              {"21 balloons for 21 beautiful years of you, Myra! Each one carries a year of your amazing journey."}
            </p>
          </div>
          <button
            onClick={onComplete}
            className="mt-6 px-7 py-3.5 bg-primary text-primary-foreground font-bold rounded-full shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 text-base sm:text-lg"
          >
            Next
          </button>
        </div>
      )}
    </section>
  )
}
