"use client"

import { useState, useCallback } from "react"
import { LoadingScreen } from "@/components/birthday/loading-screen"
import { MainCard } from "@/components/birthday/main-card"
import { CakeInteraction } from "@/components/birthday/cake-interaction"
import { BalloonPop } from "@/components/birthday/balloon-pop"
import { BirthdayQuiz } from "@/components/birthday/birthday-quiz"
import { MessageReveal } from "@/components/birthday/message-reveal"
import { FinalMessage } from "@/components/birthday/final-message"
import {
  FloatingBalloons,
  SparkleOverlay,
  ConfettiOverlay,
} from "@/components/birthday/floating-elements"

type Step =
  | "loading"
  | "main"
  | "cake"
  | "balloons"
  | "quiz"
  | "message"
  | "final"

export default function BirthdayPage() {
  const [step, setStep] = useState<Step>("loading")

  const goTo = useCallback((next: Step) => {
    setStep(next)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [])

  return (
    <main className="relative min-h-[100dvh] overflow-hidden bg-background">
      {/* Background decorations - always visible after loading */}
      {step !== "loading" && (
        <>
          <FloatingBalloons />
          <SparkleOverlay />
          {step === "final" && <ConfettiOverlay />}
        </>
      )}

      {/* Step content */}
      <div className="relative z-20">
        {step === "loading" && (
          <LoadingScreen onComplete={() => goTo("main")} />
        )}

        {step === "main" && (
          <MainCard onStart={() => goTo("cake")} />
        )}

        {step === "cake" && (
          <CakeInteraction onComplete={() => goTo("balloons")} />
        )}

        {step === "balloons" && (
          <BalloonPop onComplete={() => goTo("quiz")} />
        )}

        {step === "quiz" && (
          <BirthdayQuiz onComplete={() => goTo("message")} />
        )}

        {step === "message" && (
          <MessageReveal onComplete={() => goTo("final")} />
        )}

        {step === "final" && <FinalMessage />}
      </div>
    </main>
  )
}
